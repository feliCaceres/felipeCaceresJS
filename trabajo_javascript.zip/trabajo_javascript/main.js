let a = 5;
let b = 10;
let c = a + b;

console.log("la suma de a y b es: " + c);

let nombre = prompt("Por favor, ingresa tu nombre:");

console.log("¡Hola, " + nombre + "! Recuerda no ser Mickey Mouse.");

function mayor(a, b, c) {
  if (c > a && c > b) {return c;}
  else {
    if (b > a) {return b;}
    else {return a;}
  }
}

console.log("El mayor entre los tres números es: " + mayor(3, 7, 5));

function par(numeroIngresado) {
  if (numeroIngresado % 2 === 0) {
    console.log("El número " + numeroIngresado + " es par.");
  } else {
    console.log("El número " + numeroIngresado + " es impar.");
  }
}

par(parseInt(prompt("Ingresa un número:")));

let x = 10;

while (x!=0) {
  x = x - 1;
  console.log(x);
}

let numero = 0;
do {
  numero = parseInt(prompt("Ingresa un número mayor a 100:"));
} while (numero <= 100); 

console.log("Número ingresado: " + numero);

function esPar(numeroIngresado) {
  if (numeroIngresado % 2 === 0) {return true;}
  else {return false;}
}

console.log("el 15 es par? " + esPar(15));
console.log("el 12 es par? " + esPar(12));

function convertirCelsiusAFahrenheit(c) {return c*1.8 + 32;}

console.log(30 + "")